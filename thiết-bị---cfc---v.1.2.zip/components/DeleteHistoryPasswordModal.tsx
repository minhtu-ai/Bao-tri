
import React, { useState } from 'react';
import { XMarkIcon } from './Icons';

interface DeleteHistoryPasswordModalProps {
  onClose: () => void;
  onConfirm: () => void;
  selectedCount: number;
}

const CORRECT_PASSWORD = "xnpbhc@2025";

const DeleteHistoryPasswordModal: React.FC<DeleteHistoryPasswordModalProps> = ({ onClose, onConfirm, selectedCount }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === CORRECT_PASSWORD) {
      setError('');
      onConfirm();
    } else {
      setError('Mật khẩu không chính xác. Vui lòng thử lại.');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md transform transition-all">
        <div className="flex justify-between items-center p-4 border-b dark:border-slate-700">
          <h2 className="text-xl font-bold text-red-600 dark:text-red-400">Xác nhận xóa lịch sử</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700">
             <XMarkIcon />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6">
            <p className="mb-4">Bạn sắp xóa vĩnh viễn <span className="font-bold">{selectedCount}</span> mục khỏi lịch sử. Hành động này không thể hoàn tác.</p>
            <p className="mb-4">Vui lòng nhập mật khẩu để xác nhận.</p>
            
            <label htmlFor="delete-password" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Mật khẩu
            </label>
            <input
              id="delete-password"
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError('');
              }}
              className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 dark:bg-slate-700 dark:text-white ${error ? 'border-red-500 ring-red-500' : 'border-slate-300 dark:border-slate-600'}`}
              autoFocus
              required
            />
            {error && <p className="text-sm text-red-500 mt-2">{error}</p>}
          </div>
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 text-slate-800 rounded-md hover:bg-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500 dark:bg-slate-600 dark:text-slate-100 dark:hover:bg-slate-500"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50"
              disabled={!password}
            >
              Xác nhận xóa
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DeleteHistoryPasswordModal;
